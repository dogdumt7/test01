<template>
  <div class="tiktok-ba55d9-DivHeaderRightContainer e13wiwn60">
    <div class="tiktok-gcx66p-DivUploadContainer e18d3d940">
      <a href="#" class="e18d3d942 tiktok-2gvzau-ALink-StyledLink er1vbsz1">
        <div class="tiktok-1qup28j-DivUpload e18d3d944">
          <svg
            class="tiktok-qeydvm-StyledPlusIcon e18d3d945"
            width="1em"
            data-e2e=""
            height="1em"
            viewBox="0 0 16 16"
            fill="currentColor"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M8 2.5C7.58579 2.5 7.25 2.83579 7.25 3.25V7.25H3.25C2.83579 7.25 2.5 7.58579 2.5 8C2.5 8.41421 2.83579 8.75 3.25 8.75H7.25V12.75C7.25 13.1642 7.58579 13.5 8 13.5C8.41421 13.5 8.75 13.1642 8.75 12.75V8.75H12.75C13.1642 8.75 13.5 8.41421 13.5 8C13.5 7.58579 13.1642 7.25 12.75 7.25H8.75V3.25C8.75 2.83579 8.41421 2.5 8 2.5Z"
            ></path>
          </svg>
          <span class="tiktok-y3rt08-SpanUploadText e18d3d946">Download</span>
        </div>
      </a>
    </div>
    <div
      data-e2e="top-dm-icon"
      class="tiktok-1ibfxbr-DivMessageIconContainer e1nx07zo0"
    >
      <a
        aria-label="Открыть сообщения"
        class="tiktok-22xkqc-StyledLink er1vbsz0"
        href="#"
        ><span
          ><svg
            class="tiktok-y48l9g-StyledIcon e1nx07zo1"
            width="1em"
            data-e2e=""
            height="1em"
            viewBox="0 0 48 48"
            fill="currentColor"
            xmlns="http://www.w3.org/2000/svg"
            data-darkreader-inline-fill=""
            style="--darkreader-inline-fill: currentColor"
          >
            <path
              fill-rule="evenodd"
              clip-rule="evenodd"
              d="M2.17877 7.17357C2.50304 6.45894 3.21528 6 4.00003 6H44C44.713 6 45.372 6.37952 45.7299 6.99615C46.0877 7.61278 46.0902 8.37327 45.7365 8.99228L25.7365 43.9923C25.3423 44.6821 24.5772 45.0732 23.7872 44.9886C22.9972 44.9041 22.3321 44.3599 22.0929 43.6023L16.219 25.0017L2.49488 9.31701C1.97811 8.72642 1.85449 7.88819 2.17877 7.17357ZM20.377 24.8856L24.531 38.0397L40.5537 10H8.40757L18.3918 21.4106L30.1002 14.2054C30.5705 13.9159 31.1865 14.0626 31.4759 14.533L32.5241 16.2363C32.8136 16.7066 32.6669 17.3226 32.1966 17.612L20.377 24.8856Z"
            ></path></svg></span
      ></a>
    </div>
    <div
      tabindex="0"
      role="button"
      aria-expanded="false"
      aria-label="Входящие
Непрочитанные уведомления: 0"
      data-e2e="inbox-icon"
      class="tiktok-1b4xcc5-DivHeaderInboxContainer e18kkhh40"
    >
      <span
        ><svg
          class="tiktok-1g0p6jv-StyledInboxIcon e18kkhh41"
          width="32"
          data-e2e=""
          height="32"
          viewBox="0 0 32 32"
          fill="currentColor"
          xmlns="http://www.w3.org/2000/svg"
          data-darkreader-inline-fill=""
          style="--darkreader-inline-fill: currentColor"
        >
          <path
            fill-rule="evenodd"
            clip-rule="evenodd"
            d="M24.0362 21.3333H18.5243L15.9983 24.4208L13.4721 21.3333H7.96047L7.99557 8H24.0009L24.0362 21.3333ZM24.3705 23.3333H19.4721L17.2883 26.0026C16.6215 26.8176 15.3753 26.8176 14.7084 26.0026L12.5243 23.3333H7.62626C6.70407 23.3333 5.95717 22.5845 5.9596 21.6623L5.99646 7.66228C5.99887 6.74352 6.74435 6 7.66312 6H24.3333C25.2521 6 25.9975 6.7435 26 7.66224L26.0371 21.6622C26.0396 22.5844 25.2927 23.3333 24.3705 23.3333ZM12.6647 14C12.2965 14 11.998 14.2985 11.998 14.6667V15.3333C11.998 15.7015 12.2965 16 12.6647 16H19.3313C19.6995 16 19.998 15.7015 19.998 15.3333V14.6667C19.998 14.2985 19.6995 14 19.3313 14H12.6647Z"
          ></path></svg
      ></span>
      <div
        data-focus-guard="true"
        tabindex="-1"
        style="
          width: 1px;
          height: 0px;
          padding: 0px;
          overflow: hidden;
          position: fixed;
          top: 1px;
          left: 1px;
        "
      ></div>
      <div data-focus-lock-disabled="disabled">
        <div
          role="dialog"
          aria-label="Уведомления"
          class="tiktok-1idvj23-DivHeaderInboxWrapper e18kkhh49"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="rgba(255, 255, 255, 1)"
            viewBox="0 0 24 8"
            width="24"
            height="8"
            class="tiktok-e0rxz1-StyledArrow e18kkhh48"
            data-darkreader-inline-fill=""
            style="--darkreader-inline-fill: #e8e6e3"
          >
            <path d="M0 8c7 0 10-8 12-8s5 8 12 8z"></path>
          </svg>
          <div
            data-e2e="inbox-notifications"
            class="tiktok-vubwh3-DivInboxContainer e32s1fi0"
          >
            <div class="tiktok-19hvf92-DivInboxHeaderContainer e1bp8k4k0">
              <h2
                id="header-inbox-title"
                class="tiktok-1be78j5-H2InboxTitle e1bp8k4k1"
              >
                Уведомления
              </h2>
              <div
                data-e2e="inbox-bar"
                id="header-inbox-bar"
                role="tablist"
                aria-labelledby="header-inbox-title"
                class="tiktok-l8mfo-DivGroupContainer e1bp8k4k3"
              >
                <button
                  data-e2e="all"
                  id="inbox-tab-0"
                  tabindex="0"
                  role="tab"
                  aria-selected="true"
                  aria-controls="header-inbox-list"
                  class="tiktok-7gu37x-ButtonGroupItem e1bp8k4k4"
                >
                  Вся активность</button
                ><button
                  data-e2e="likes"
                  id="inbox-tab-1"
                  tabindex="-1"
                  role="tab"
                  aria-selected="false"
                  aria-controls="header-inbox-list"
                  class="tiktok-18a9ome-ButtonGroupItem e1bp8k4k4"
                >
                  Лайки</button
                ><button
                  data-e2e="comments"
                  id="inbox-tab-2"
                  tabindex="-1"
                  role="tab"
                  aria-selected="false"
                  aria-controls="header-inbox-list"
                  class="tiktok-18a9ome-ButtonGroupItem e1bp8k4k4"
                >
                  Комментарии</button
                ><button
                  data-e2e="mentions"
                  id="inbox-tab-3"
                  tabindex="-1"
                  role="tab"
                  aria-selected="false"
                  aria-controls="header-inbox-list"
                  class="tiktok-18a9ome-ButtonGroupItem e1bp8k4k4"
                >
                  Упоминания и отметки</button
                ><button
                  data-e2e="followers"
                  id="inbox-tab-4"
                  tabindex="-1"
                  role="tab"
                  aria-selected="false"
                  aria-controls="header-inbox-list"
                  class="tiktok-18a9ome-ButtonGroupItem e1bp8k4k4"
                >
                  Подписчики
                </button>
              </div>
            </div>
            <div
              data-e2e="inbox-list"
              id="header-inbox-list"
              tabindex="0"
              role="tabpanel"
              aria-labelledby="inbox-tab-0"
              class="tiktok-o6y5r-DivInboxContentContainer e11z9zg00"
            >
              <p class="tiktok-1bogf35-PTimeGroupTitle e11z9zg01">Then</p>
              <ul class="tiktok-1cz26jb-UlInboxItemListContainer e11z9zg011">
                <li class="tiktok-1lqaxb-LiInboxItemWrapper e11z9zg012">
                  <div
                    class="tiktok-1c5mw4z-DivSystemNotifItemContainer exfus516"
                  >
                    <div
                      class="tiktok-rlx2vl-DivSystemNotifIconContainer exfus517"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 18 16"
                        width="16"
                        height="16"
                      >
                        <path
                          fill="white"
                          d="M14.24 0c.828 0 1.56.454 1.808 1.123l1.78 4.81c.113.307.172.63.172.955V14.4c0 .425-.2.832-.555 1.131-.355.3-.837.469-1.34.469H1.895c-.503 0-.985-.168-1.34-.469C.2 15.232 0 14.824 0 14.4V6.888c0-.325.059-.648.173-.955l1.78-4.81C2.202.455 2.934 0 3.762 0h10.478zm-.918 2.133H4.678c-.284 0-.54.15-.651.379l-.031.079-.982 3.16a.5.5 0 00.477.649h11.017a.5.5 0 00.478-.648l-.983-3.161c-.083-.27-.363-.457-.681-.458z"
                          data-darkreader-inline-fill=""
                          style="--darkreader-inline-fill: #e8e6e3"
                        ></path>
                      </svg>
                    </div>
                    <div class="tiktok-14aeum4-DivContentContainer exfus56">
                      <p class="tiktok-1mdj9uu-PTitleText exfus57">
                        Уведомления system
                      </p>
                      <p class="tiktok-k3qjpf-PSystemNotifDescText exfus519">
                        TikTok: В ближайшие недели мы начинаем вводить функцию
                        создания стикеров для личных сообщений на основе ваших
                        видео в TikTok! Как автор, вы сами решаете, можно ли
                        другим пользователям создавать стикеры для личных
                        сообщений на основе ваших видео. Для управления этим
                        разрешением откройте «Настройки и конфиденциальность»
                        &gt; «Конфиденциальность» &gt; «Личные сообщения».
                      </p>
                    </div>
                    <div class="tiktok-ybcak8-DivArrowContainer exfus518">
                      <svg
                        fill="currentColor"
                        viewBox="0 0 48 48"
                        xmlns="http://www.w3.org/2000/svg"
                        width="1em"
                        height="1em"
                        class="flip-rtl"
                        style="
                          font-size: 16px;
                          --darkreader-inline-fill: currentColor;
                        "
                        data-darkreader-inline-fill=""
                      >
                        <path
                          d="M35.41 22.59 19.12 6.29a1 1 0 0 0-1.41 0l-1.42 1.42a1 1 0 0 0 0 1.41L31.17 24 16.3 38.88a1 1 0 0 0 0 1.41l1.42 1.42a1 1 0 0 0 1.41 0l16.3-16.3a2 2 0 0 0 0-2.82Z"
                        ></path>
                      </svg>
                    </div>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="tiktok-1igqi6u-DivProfileContainer efubjyv0">
      <!-- API PATH -->
      <img src="/api/data/image.png" alt="" />
    </div>
  </div>
</template>
